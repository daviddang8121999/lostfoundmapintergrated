package com.example.lostfoundmap;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;

public class lostFoundList extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_lost_found_list);
    }
}